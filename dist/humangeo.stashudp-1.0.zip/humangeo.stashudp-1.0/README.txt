.. contents::

Introduction
============

StashUDP is a logging handler that allows you to emit log messages in LogStash format to ElasticSearch.